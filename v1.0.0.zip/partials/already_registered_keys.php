<div class="abprotector_configuration_wrapper">
    <div class="top_header">
        <img class="icon_img" src="<?php echo esc_url(ABPROTECTOR_PLUGIN_URL . '/resources/images/logo-abandonment.png'); ?>">
        <br>
        <p class="fs22 light"> 
            Simple tools to create marketing automation depending on your customer's behavior.
        </p>
    </div>

    <div class="step_container">
        <a href="<?php echo esc_url(ABPROTECTOR_APP_URL); ?>/wp/login?shop=<?php echo esc_attr($shop_domain); ?>" class="chp_btn btn_teal btn_lg" target="_blank">
            <strong>Go to Abandonment Protector</strong>
        </a>
    </div>

    <div class="step_container fs18">
        <div>
            <strong>Public key:</strong>
            <span><?php echo filter_var(substr($abprotector_keys['api_key'], 0, 7) . "..." . substr($abprotector_keys['api_key'], -5), FILTER_SANITIZE_STRING); ?></span>
        </div>
        <div>
            <?php if( $keys_validation_status == false ){ ?>
                <div class='msg_api_keys valid'>Connected</div>
            <?php }else{ ?>
                <div class='msg_api_keys invalid'>Invalid API keys, please check you have copied them correctly.</div>
            <?php } ?>
        </div>
        <br>
        <div class="btn_change_keys_wrapper">
            <button class="button-secondary btn_change_abprotector_keys">Change keys</button>
        </div>

        <div id="chp_form_keys_container" style="display: none; margin-top: 10px;">
            <form method="post" action="options.php">
                <?php
                    settings_fields( 'abprotector_settings' );
                    do_settings_sections( 'abprotector_admin_settings' );
                ?>

                <div class="mtop20">
                    <button class="chp_btn btn_teal btn_change_abprotector_keys">Save changes</button>
                    <button class="chp_btn btn_cancel_abprotector_keys fs14">Cancel</button>
                </div>
            </form>
        </div>
    </div>
</div>
<div class="notice notice-error" style="margin-top: 20px;">
    <p style="font-size: 16px;">
        <strong style='color: #0a4883;'>Abandonment Protector</strong> provides additional features if the <strong>WooCommerce</strong> plugin is installed & activated.
    </p>
</div>
<?php
    class AbprotectorPopups{

        // ------- cargar el script de popups si hay -------

        function add_abprotector_popups_script(){
            $scripts = get_option('abprotector_popup_scripts');

            if( $scripts == false ){
                return;
            }

            $scripts = json_decode($scripts);

            // IMPORTANTE: CAMBIAR LA VERSION AL HACER CAMBIOS
            // $version = 1;

            foreach ($scripts as $script_url){
                wp_enqueue_script(
                    'abprotector-popups',
                    $script_url,
                    array( 'jquery' )
                );
            }
        }

    }
?>